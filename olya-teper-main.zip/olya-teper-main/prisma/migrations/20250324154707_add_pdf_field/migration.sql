-- AlterTable
ALTER TABLE "Book" ADD COLUMN     "pdfUrl" TEXT;
